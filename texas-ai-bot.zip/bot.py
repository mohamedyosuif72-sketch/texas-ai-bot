import os
import logging
import anthropic
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes, CallbackQueryHandler

# Configuration
TELEGRAM_TOKEN = "9106780728:AAGDA_E_CU6t-nB6e7eLEPvl939XSpcmnNM"
ANTHROPIC_API_KEY = "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"

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)

client = anthropic.Anthropic(api_key=ANTHROPIC_API_KEY)

SYSTEM_PROMPT = """أنت TEXAS AI، مساعد تنفيذي ذكي ومتقدم باللغة العربية.
مهامك:
- مساعدة في إدارة الأعمال والمشاريع
- متابعة أخبار جامعة بحري
- صناعة المحتوى الإبداعي
- إنشاء تقارير يومية ذكية
- إدارة المهام والجداول
- تقديم استشارات احترافية

أسلوبك: احترافي، ذكي، مباشر، وباللغة العربية دائماً.
اسمك: TEXAS AI | المساعد التنفيذي"""

conversation_history = {}

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keyboard = [
        [InlineKeyboardButton("📚 جامعة بحري", callback_data='university'),
         InlineKeyboardButton("✍️ صناعة المحتوى", callback_data='content')],
        [InlineKeyboardButton("💼 إدارة الأعمال", callback_data='business'),
         InlineKeyboardButton("📊 التقرير اليومي", callback_data='report')],
        [InlineKeyboardButton("✅ المهام", callback_data='tasks'),
         InlineKeyboardButton("ℹ️ معلومات", callback_data='about')]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    welcome_text = """🤖 *TEXAS AI | المساعد التنفيذي الذكي*

مرحباً! أنا مساعدك الشخصي المدعوم بالذكاء الاصطناعي.

اختر ما تريد أو اكتب سؤالك مباشرة 👇"""
    
    await update.message.reply_text(welcome_text, parse_mode='Markdown', reply_markup=reply_markup)

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    help_text = """📋 *الأوامر المتاحة:*

/start - تشغيل المساعد
/help - عرض المساعدة
/university - أخبار جامعة بحري
/content - صناعة المحتوى
/business - إدارة الأعمال
/report - التقرير اليومي
/tasks - إدارة المهام
/about - معلومات عن المساعد
/clear - مسح سجل المحادثة

💬 أو اكتب أي سؤال مباشرة!"""
    await update.message.reply_text(help_text, parse_mode='Markdown')

async def university_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    await ask_claude(update, context, user_id, "أعطني آخر المستجدات والنصائح المتعلقة بجامعة بحري في السودان، وكيف يمكن متابعة أخبارها")

async def content_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("""✍️ *وضع صناعة المحتوى*

ماذا تريد إنشاء؟

• اكتب موضوع المحتوى
• أو اختر نوعه: منشور، مقال، سكريبت فيديو، إعلان...""", parse_mode='Markdown')

async def business_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("""💼 *وضع إدارة الأعمال*

كيف أساعدك اليوم؟

• تحليل مشروع
• خطة عمل
• استراتيجية تسويق
• حل مشكلة تجارية

اكتب ما تحتاجه 👇""", parse_mode='Markdown')

async def report_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    await ask_claude(update, context, user_id, "أنشئ لي تقرير يومي احترافي يشمل: ملخص إنجازات اليوم، المهام المقترحة للغد، ونصيحة تحفيزية. اجعله منظماً وجاهزاً للاستخدام")

async def tasks_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("""✅ *إدارة المهام*

أرسل مهامك وسأساعدك في:

• ترتيب الأولويات
• تقسيم المهام الكبيرة
• وضع جدول زمني
• متابعة التقدم

اكتب مهامك 👇""", parse_mode='Markdown')

async def about_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    about_text = """🤖 *TEXAS AI | المساعد التنفيذي*

مدعوم بـ Claude AI من Anthropic

*القدرات:*
✅ محادثة ذكية باللغة العربية
✅ إدارة الأعمال والمشاريع
✅ صناعة المحتوى الإبداعي
✅ متابعة الجامعة
✅ تقارير يومية ذكية
✅ ذاكرة المحادثة

_Your goals. Your assistant. Your success._"""
    await update.message.reply_text(about_text, parse_mode='Markdown')

async def clear_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if user_id in conversation_history:
        conversation_history[user_id] = []
    await update.message.reply_text("✅ تم مسح سجل المحادثة. ابدأ محادثة جديدة!")

async def ask_claude(update: Update, context: ContextTypes.DEFAULT_TYPE, user_id: int, text: str):
    if user_id not in conversation_history:
        conversation_history[user_id] = []
    
    conversation_history[user_id].append({"role": "user", "content": text})
    
    # Keep only last 20 messages
    if len(conversation_history[user_id]) > 20:
        conversation_history[user_id] = conversation_history[user_id][-20:]
    
    thinking_msg = await update.effective_message.reply_text("⏳ جاري المعالجة...")
    
    try:
        response = client.messages.create(
            model="claude-sonnet-4-6",
            max_tokens=1500,
            system=SYSTEM_PROMPT,
            messages=conversation_history[user_id]
        )
        
        reply = response.content[0].text
        conversation_history[user_id].append({"role": "assistant", "content": reply})
        
        await thinking_msg.delete()
        
        # Split long messages
        if len(reply) > 4000:
            parts = [reply[i:i+4000] for i in range(0, len(reply), 4000)]
            for part in parts:
                await update.effective_message.reply_text(part)
        else:
            await update.effective_message.reply_text(reply)
            
    except Exception as e:
        await thinking_msg.delete()
        await update.effective_message.reply_text(f"❌ خطأ: {str(e)}")

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    text = update.message.text
    await ask_claude(update, context, user_id, text)

async def handle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id
    
    callbacks = {
        'university': 'أعطني معلومات مفيدة عن جامعة بحري في السودان وكيف أتابع أخبارها',
        'content': 'أريد مساعدة في صناعة المحتوى الرقمي',
        'business': 'أريد مساعدة في إدارة أعمالي ومشاريعي',
        'report': 'أنشئ لي تقرير يومي احترافي منظم',
        'tasks': 'أريد مساعدة في إدارة مهامي وترتيب أولوياتي',
        'about': None
    }
    
    if query.data == 'about':
        await query.message.reply_text("""🤖 *TEXAS AI | المساعد التنفيذي*
مدعوم بـ Claude AI من Anthropic
_Your goals. Your assistant. Your success._""", parse_mode='Markdown')
    elif query.data in callbacks:
        await ask_claude(update, context, user_id, callbacks[query.data])

def main():
    app = Application.builder().token(TELEGRAM_TOKEN).build()
    
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_command))
    app.add_handler(CommandHandler("university", university_command))
    app.add_handler(CommandHandler("content", content_command))
    app.add_handler(CommandHandler("business", business_command))
    app.add_handler(CommandHandler("report", report_command))
    app.add_handler(CommandHandler("tasks", tasks_command))
    app.add_handler(CommandHandler("about", about_command))
    app.add_handler(CommandHandler("clear", clear_command))
    app.add_handler(CallbackQueryHandler(handle_callback))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    
    logger.info("TEXAS AI Bot is running...")
    app.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == '__main__':
    main()
